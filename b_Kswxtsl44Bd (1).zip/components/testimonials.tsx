"use client"

import { useCallback, useEffect, useState } from "react"
import useEmblaCarousel from "embla-carousel-react"
import Autoplay from "embla-carousel-autoplay"
import { Star, ChevronLeft, ChevronRight } from "lucide-react"
import Image from "next/image"
import { motion } from "framer-motion"

const testimonials = [
  {
    name: "Rajesh Kulkarni",
    rating: 5,
    review: "OralNest provided exceptional care during my root canal treatment. The team was professional, and the procedure was completely painless. Highly recommended!",
    image: 11,
  },
  {
    name: "Sunita Deshpande",
    rating: 5,
    review: "I was nervous about getting dental implants, but Dr. Priya made me feel comfortable throughout the process. My new smile looks amazing and natural!",
    image: 20,
  },
  {
    name: "Amit Pawar",
    rating: 5,
    review: "The clinic is modern and clean. The staff is very friendly and attentive. My teeth whitening results exceeded my expectations. Thank you OralNest!",
    image: 13,
  },
  {
    name: "Priya Joshi",
    rating: 4,
    review: "Great experience with my dental checkup. The doctors explained everything clearly and the treatment was affordable. Will definitely come back.",
    image: 25,
  },
  {
    name: "Vikram Sharma",
    rating: 5,
    review: "After years of avoiding dentists, I finally found a clinic that understands patient anxiety. The team at OralNest is truly caring and skilled.",
    image: 15,
  },
  {
    name: "Anjali Patil",
    rating: 5,
    review: "My orthodontic treatment here was perfect. The braces were adjusted correctly every visit and my teeth are now perfectly aligned. Best dental clinic in Pune!",
    image: 30,
  },
]

export function Testimonials() {
  const [emblaRef, emblaApi] = useEmblaCarousel(
    { loop: true, align: "start" },
    [Autoplay({ delay: 4000, stopOnInteraction: false })]
  )
  const [selectedIndex, setSelectedIndex] = useState(0)

  const scrollPrev = useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev()
  }, [emblaApi])

  const scrollNext = useCallback(() => {
    if (emblaApi) emblaApi.scrollNext()
  }, [emblaApi])

  const onSelect = useCallback(() => {
    if (!emblaApi) return
    setSelectedIndex(emblaApi.selectedScrollSnap())
  }, [emblaApi])

  useEffect(() => {
    if (!emblaApi) return
    onSelect()
    emblaApi.on("select", onSelect)
  }, [emblaApi, onSelect])

  return (
    <section id="testimonials" className="py-16 bg-white">
      <div className="container mx-auto px-4 lg:px-8">
        {/* Header */}
        <motion.div
          className="text-center max-w-2xl mx-auto mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-sm font-medium text-primary uppercase tracking-wider mb-2">
            What Our Patients Say
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            Real Results, <span className="text-primary">Real Smiles</span>
          </h2>
        </motion.div>

        {/* Carousel */}
        <motion.div
          className="relative"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="overflow-hidden" ref={emblaRef}>
            <div className="flex gap-6">
              {testimonials.map((testimonial, index) => (
                <div
                  key={index}
                  className="flex-[0_0_100%] md:flex-[0_0_50%] lg:flex-[0_0_33.333%] min-w-0"
                >
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.05 }}
                    className="bg-white rounded-2xl border border-border p-6 h-full hover:border-primary/40 transition-colors"
                  >
                    {/* Quote */}
                    <div className="text-4xl text-primary/20 font-serif mb-4">&ldquo;</div>
                    
                    {/* Review */}
                    <p className="text-muted-foreground mb-6 line-clamp-4">
                      {testimonial.review}
                    </p>
                    
                    {/* Rating */}
                    <div className="flex gap-1 mb-4">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < testimonial.rating
                              ? "fill-amber-400 text-amber-400"
                              : "fill-gray-200 text-gray-200"
                          }`}
                        />
                      ))}
                    </div>
                    
                    {/* Author */}
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-primary/20">
                        <Image
                          src={`https://i.pravatar.cc/48?img=${testimonial.image}`}
                          alt={testimonial.name}
                          width={48}
                          height={48}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <div className="font-semibold text-foreground">
                          {testimonial.name}
                        </div>
                        <div className="text-sm text-primary">Verified Patient</div>
                      </div>
                    </div>
                  </motion.div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Buttons */}
          <button
            onClick={scrollPrev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 w-10 h-10 rounded-full bg-white border border-border shadow-lg flex items-center justify-center hover:border-primary/40 transition-colors hidden md:flex"
          >
            <ChevronLeft className="w-5 h-5 text-foreground" />
          </button>
          <button
            onClick={scrollNext}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 w-10 h-10 rounded-full bg-white border border-border shadow-lg flex items-center justify-center hover:border-primary/40 transition-colors hidden md:flex"
          >
            <ChevronRight className="w-5 h-5 text-foreground" />
          </button>
        </motion.div>

        {/* Dots */}
        <div className="flex justify-center gap-2 mt-8">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => emblaApi?.scrollTo(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                index === selectedIndex
                  ? "w-6 bg-primary"
                  : "bg-gray-300 hover:bg-gray-400"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  )
}
